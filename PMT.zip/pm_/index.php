<?php

include "../functions.php";
set_include_path(htdocs);
include htdocs . "pm.php";
echo htdocs . "pm.php";
?>
<!-- <html>
<head>
	<title>Redirect</title>
</head>
<script>
	window.location.replace("../pm.php");
</script>
</html> -->
