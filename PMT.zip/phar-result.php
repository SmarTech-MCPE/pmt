<?php
include("lang/setlang.php");
define('PACKAGE', 'phar');

// gettext setting
bindtextdomain(PACKAGE, 'lang'); // or $your_path/lang, ex: /var/www/test/lang
textdomain(PACKAGE);
?>
<?php
include "functions.php";
$jsonExpected = $_SERVER["HTTP_ACCEPT"] === "application/json";
if(!$jsonExpected):
?>
<html>
<head>
	<title>Zip » Phar - Résultat</title>
<link rel="stylesheet" href="/css/main.css" />
</head>
<body>
<font face="Comic Sans MS">
	<?php endif; ?>
	<?php

	use inspections\BadPracticeInspection;
	use inspections\ClasspathInspection;
	use inspections\SyntaxErrorInspection;

	if(!isset($_FILES["file"])){
		http_response_code(400);
		$out = "Merci d'accéder à cette page <b>après</b> avoir upload un fichier.";
		echo $jsonExpected ? json_encode(["error" => $out]) : $out;
		return;
	}
	$file = $_FILES["file"];
if($file["error"] !== 0){
	echo "<h1>Erreur</h1>";
	echo "Upload invalide : ";
	switch($err = $file["error"]){
		case UPLOAD_ERR_INI_SIZE:
			echo "Fichier trop volumineux UPLOAD_ERR_INI_SIZE($err)";
			break;
		case UPLOAD_ERR_FORM_SIZE:
			echo "Fichier trop volumineux UPLOAD_ERR_FORM_SIZE($err)";
			break;
		case UPLOAD_ERR_PARTIAL:
			echo "Le fichier est partiellement upload UPLOAD_ERR_PARTIAL($err)";
			break;
		case UPLOAD_ERR_NO_FILE:
			echo "Aucun fichier upload UPLOAD_ERR_NO_FILE($err)";
			break;
		case UPLOAD_ERR_NO_TMP_DIR:
			echo "Il manque un dossier temporaire UPLOAD_ERR_NO_TMP_DIR($err)";
			break;
		case UPLOAD_ERR_CANT_WRITE:
			echo "Impossible de modifier le fichier UPLOAD_ERR_CANT_WRITE($err)";
			break;
		case UPLOAD_ERR_EXTENSION:
			echo "Une extension PHP a bloqué l'upload du fichier UPLOAD_ERR_EXTENSION($err)";
			break;
		}
		if(!$jsonExpected){
			goto the_end;
		}else{
			echo json_encode(["error" => $errMsg]);
			die;
		}
	}
	$args = new TuneArgs;
	$tno = "tune_top_namespace_optimization";
	$obs = "tune_obfuscation";
	$args->topNamespaceBackslash = isset($_POST[$tno]) ? ($_POST[$tno] === "on") : false;
	$args->obfuscate = isset($_POST[$tno]) ? ($_POST[$tno] === "on") : false;
	$result = phar_buildFromZip($file["tmp_name"], substr($file["name"], 0, -4), $args);
	if($result["error"] !== MAKEPHAR_ERROR_NO){
		if(!$jsonExpected){
			echo _("<h1>Impossible de créer le phar</h1>");
			echo _("<p>Error: ");
			echo $MAKEPHAR_ERROR_MESSAGES[$result["error"]];
			echo "<br>";
			echo "<code>" . $result["error_name"] . "(" . $result["erorr_id"] . ")</code>: ";
			echo $result["error_msg"];
			echo "</p>";
			goto the_end;
		}else{
			json_encode(["error" => $MAKEPHAR_ERROR_MESSAGES[$result["error"]]]);
		}
	}
	$url = $result["pharpath"];
	$basename = urlencode(substr($url, 12));

	$cnt = usage_inc("pharbuild", $time);
	$diff = time() - $time;
	$itv = "";
	if($diff >= 3600 * 24){
		$itv .= ((int) ($diff / (3600 * 24))) . " jour(s), ";
		$diff %= 3600 * 24;
		while($diff < 0){
			$diff += 3600 * 24;
		}
	}
	if($diff >= 3600){
		$itv .= ((int) ($diff / 3600)) . " heure(s), ";
		$diff %= 3600;
		while($diff < 0){
			$diff += 3600;
		}
	}
	if($diff >= 60){
		$itv .= ((int) ($diff / 60)) . " minute(s), ";
		$diff %= 60;
		while($diff < 0){
			$diff += 60;
		}
	}
	$itv .= "$diff second(s)";
	/** @var inspections\Inspection[] $inspections */
	$inspections = [];
	$dir = $result["extractpath"];
	foreach(["inspection_classpath", "inspection_bad_practice", "inspection_lint"] as $field){
		if(!isset($_POST[$field])){
			$_POST[$field] = "off";
		}
	}
	if($_POST["inspection_classpath"] === "on"){
		$inspections[] = new ClasspathInspection($dir);
	}
	if($_POST["inspection_bad_practice"] === "on"){
		$inspections[] = new BadPracticeInspection($dir);
	}
	if($_POST["inspection_lint"] === "on"){
		$inspections[] = new SyntaxErrorInspection($dir);
	}
	if($jsonExpected){
		$jsonData = [
			"phar" => "http://pmt.mcpe.fun" . $url,
			"expiry" => time() + 7200,
			"inspections" => []
		];
		foreach($inspections as $inspection){
			$jsonData["inspections"][$result->getName()] = $inspection->run()->jsonResult();
		}
		echo json_encode($jsonData);
		die;
	}
	echo <<<EOP
<h1>La conversion est terminée.</h1>
<p>Téléchargez le fichier <a href="/data/dl.php?name=$basename">ici</a>.
<p>Le lien de téléchargement fonctionnera pendant <b>2 heures</b>.</p>
EOP;
	echo _("<p>Depuis le début de ce site, $itv, $cnt phars ont été créés.</p>");
	echo "<hr>";
	echo _("<h2>Inspections :</h2>");
	echo "<ul>";
	foreach($inspections as $inspection){
		$inspection->run()->htmlEcho();
	}
	echo "</ul>";
	echo _("<p>Fin des inspections.</p>");
	?>
	<p><?php echo _('Vous pouvez aussi vérifier votre phar sur <a href="http://www.pocketmine.net/pluginReview.php"
	                                                         target="_blank">l'outil officiel de vérification de plugins</a> pour vérifier vos erreurs et les informations du plugin.'); ?></p>
	<?php the_end: ?>
</body>
</html>
