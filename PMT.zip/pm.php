<?php

header("Location: pocketmine.php");
