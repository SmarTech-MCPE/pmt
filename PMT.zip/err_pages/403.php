<html>
<head>
	<title>Erreur 403 - Accès refusé</title>
	<style type="text/css">
		body{
			font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
		}
	</style>
</head>
<body>
<h1>Accès refusé</h1>
<p>Vous essayez de rejoindre une page qui est a accès restreint. Si vous pensez qu'il s'agit d'une erreur, dites le nous <a href="https://github.com/SmarTech-MCPE/pmt/issues/>ici</a> ou revenez en <a href="javascript:window.history.back();">arrière</a></p>
</body>
</html>
