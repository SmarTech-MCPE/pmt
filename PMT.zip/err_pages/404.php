<html>
<head>
	<title>Erreur 404</title>
	<style type="text/css">
		body{
			font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
		}
	</style>
</head>
<body>
<h1>Oups</h1>
<p>Il semble que la page que vous vous appretiez à rejoindre n'existe pas ou plus...
</p>
<p>Voulez vous revenir en <a href="javascript:window.history.back();">arrière</a> ?</p>
</body>
</html>

<?php
touch($log = "/var/www/404.log");
file_put_contents($log, PHP_EOL . date(DATE_ATOM) . " | " . $_SERVER["REQUEST_URI"] . " | " . (isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"] : "no-referer"), FILE_APPEND);
?>
