<?php
include("lang/setlang.php");
define('PACKAGE', 'pocketmine-frame-up');

// gettext setting
bindtextdomain(PACKAGE, 'lang'); // or $your_path/lang, ex: /var/www/test/lang
textdomain(PACKAGE);
?>
<html><head><title>SmarTech MCPE | PMT</title>

<link rel="stylesheet" href="/css/main.css" />
</head>
<body>
	<h1>
		<a name="title"><?php echo _('Outils de création de plugins PocketMine'); ?></a>
	</h1>
	<?php echo _('Ce projet est open source sur
	<a href="https://github.com/SmarTech-MCPE/pmt/" target="_blank">GitHub</a>.'); ?>
	<br>
	<?php echo _('Merci de prendre le temps de nous avertir des problèmes que vous rencontrez sur le site sur
	<a href="https://github.com/SmarTech-MCPE/pmt/issues" target="_blank">l'espace d'aide et de rapport</a>.
	Quand vous créez un rapport, veuillez donner le plus d'informations que vous le pouvez.'); ?>
	<br>
	<?php echo _('La base de ce site Web provient du travail de <a href="https://github.com/PEMapModder">PEMapModder</a> (avec l'aide de plusieurs personnes) et est désormais hébergé et traduit par <a href="http://smrtk.ga" target="_blank">SmarTech MCPE</a>.'); ?>

<a name="bottom"></a>
</body></html>
