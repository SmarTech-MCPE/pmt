<?php
include("lang/setlang.php");
define('PACKAGE', 'unphar');

// gettext setting
bindtextdomain(PACKAGE, 'lang'); // or $your_path/lang, ex: /var/www/test/lang
textdomain(PACKAGE);
?>
<html>
<head> 
	<title>Phar » Zip</title>
	<link rel="stylesheet" href="/css/main.css" />
</head>
<body>
<h1>Conversion <b>phar » zip</b> </h1>
<hr>
<form method="post" action="/unpharResult.php" enctype="multipart/form-data">
	<p><?php echo _('Uploadez le fichier ici :'); ?><br><input type="file" name="file" accept=".phar"></p>
	<p><input type="submit" value="Convertir"></p>
</form>
<pre>
	<?php echo _("Informations :
	Ce service est fourni gratuitement et n'est pas garanti pour être toujours disponible.
Cette page (unphar.php) convertit uniquement les fichiers téléchargés depuis les utilisateurs d'un format phar vers un format zip et, dans le processus, le fichier phar est extrait dans les fichiers sur le système de fichiers du serveur (ce qui n'est pas prévu sur le site) . Cette page décompose les fichiers téléchargés AS-IS et le processus est entièrement automatisé.
Ce site web n'est en aucun cas affilié à PocketMine-MP (http://pocketmine.net), un projet open source développé par PocketMine Team, ou Minecraft: PE, un jeu Logiciel développé par Mojang.
Nous (le propriétaire de ce site Web) ne sommes pas responsables des actes liés aux violations du droit d'auteur et à d'autres actes illégaux. Tous les contenus dans les fichiers téléchargés sont générés à l'aide du fichier téléchargé ou du logiciel utilisé pour ce site. ");?>"); ?>
</pre>

</body>
</html>
