<?php
include "functions.php";
?><html>
<head>
	<title>Phar » Zip - Résultat</title>
	<link rel="stylesheet" href="/css/main.css" />
	<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
	<script>
		$(document).ready(function(){
			var dl = $("#dlButton");
			if(typeof pmt.agree.lock !== typeof undefined){
				var agreeKey = "oui";
				if(typeof pmt.agree.key !== typeof undefined){
					agreeKey = pmt.agree.key;
				}else{
					agreeLock += "\nTapez \"oui\" si vous acceptez les termes et conditions.";
				}
				if(prompt(pmt.agree.lock).toLowerCase() != agreeKey.toLowerCase()){
					alert("Vous devez accepter les termes pour télécharger le zip !");
					window.location.replace("/unphar.php");
					return;
				}
			}
			dl.css("display", "block");
		});
	</script>
</head>
<body>
<?php
if(!isset($_FILES["file"])){
	http_response_code(400);
	echo <<<EOD
<h1>ERREUR 400</h1>
<p>Aucun fichier n'a été upload. Merci d'upload votre phar pour continuer.</p>
EOD;
	return;
}
$file = $_FILES["file"];
if($file["error"] !== 0){
	echo "<h1>Erreur</h1>";
	echo "Upload invalide : ";
	switch($err = $file["error"]){
		case UPLOAD_ERR_INI_SIZE:
			echo "Fichier trop volumineux UPLOAD_ERR_INI_SIZE($err)";
			break;
		case UPLOAD_ERR_FORM_SIZE:
			echo "Fichier trop volumineux UPLOAD_ERR_FORM_SIZE($err)";
			break;
		case UPLOAD_ERR_PARTIAL:
			echo "Le fichier est partiellement upload UPLOAD_ERR_PARTIAL($err)";
			break;
		case UPLOAD_ERR_NO_FILE:
			echo "Aucun fichier upload UPLOAD_ERR_NO_FILE($err)";
			break;
		case UPLOAD_ERR_NO_TMP_DIR:
			echo "Il manque un dossier temporaire UPLOAD_ERR_NO_TMP_DIR($err)";
			break;
		case UPLOAD_ERR_CANT_WRITE:
			echo "Impossible de modifier le fichier UPLOAD_ERR_CANT_WRITE($err)";
			break;
		case UPLOAD_ERR_EXTENSION:
			echo "Une extension PHP a bloqué l'upload du fichier UPLOAD_ERR_EXTENSION($err)";
			break;
	}
	goto end;
}
unphar_toZip($file["tmp_name"], $result, substr($file["name"], 0, -5));
$pmt = [];
/** @var string|null $tmpDir */
/** @var string|null $zipPath */
/** @var string|null $zipRelativePath */
/** @var string|null $basename */
/** @var bool $error */
extract($result);
if(!is_array($pmt)) $pmt = [];
if($error){
	goto end;
}
usage_inc("unphar", $timestamp);
echo "<script>var pmt = " + json_encode($pmt) + ";</script>";
echo <<<EOS
<h1>Succès</h1>
<p>Le phar a bien été convertit en zip !<br>
Téléchargez le zip <a id="dlButton" href="$zipRelativePath">ici</a>.
<p>Le lien de téléchargement fonctionnera pendant <b>2 heures</b>.</p>
EOS;
end:
?>
</body>
</html>
