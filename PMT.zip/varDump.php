<?php
include("lang/setlang.php");
define('PACKAGE', 'varDump');

// gettext setting
bindtextdomain(PACKAGE, 'lang'); // or $your_path/lang, ex: /var/www/test/lang
textdomain(PACKAGE);
?>
<html><head><title><?php echo _('var_dump parser'); ?></title>
<link rel="stylesheet" href="/css/main.css" />
</head>
<body>
<h1><?php echo _('<code>var_dump</code> parser'); ?></h1>
<hr>
<form action="varDumpResult.php" method="post"><input type="submit"><?php echo _('&nbsp;Merci de copier votre output <code>var_dump</code> en dessous et d'appuyer sur le bouton <code>submit</code>.'); ?><br>
	<b><?php echo _('Warning:'); ?> </b><?php echo _("Assurez-vous de ne pas copier les fins de lignes de"); ?> <code>\r\n</code> <?php echo _('to'); ?> <code>\n/\r</code> <?php echo _('or from'); ?> <code>\n/\r</code> <?php echo _('to'); ?> <code>\r\n</code> !<br>
	<textarea name="dump" rows="30" cols="150"></textarea>
</form></body></html>
