<?php

namespace pg\classes\executor\stmt\getter;

use pg\classes\executor\expression\Expression;
use pg\classes\executor\stmt\Statement;

abstract class GetterCallStatement extends Statement implements Expression{

}
