<?php

namespace pg\classes\executor\expression;

interface BooleanExpression extends Expression{

}
