<?php

namespace pg\classes\executor\expression\operands;

use pg\classes\executor\expression\ObjectExpression;

class ObjectOperandExpression extends DoubleOperandExpression implements ObjectExpression{

}
