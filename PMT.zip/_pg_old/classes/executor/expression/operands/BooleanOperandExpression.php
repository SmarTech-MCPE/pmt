<?php

namespace pg\classes\executor\expression\operands;

use pg\classes\executor\expression\BooleanExpression;

class BooleanOperandExpression extends DoubleOperandExpression implements BooleanExpression{

}
