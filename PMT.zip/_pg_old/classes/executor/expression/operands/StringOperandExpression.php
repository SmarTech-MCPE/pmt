<?php

namespace pg\classes\executor\expression\operands;

use pg\classes\executor\expression\StringExpression;

class StringOperandExpression extends DoubleOperandExpression implements StringExpression{

}
