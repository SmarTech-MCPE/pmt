<?php

namespace pg\classes\executor\expression;

interface StringExpression extends Expression{

}
