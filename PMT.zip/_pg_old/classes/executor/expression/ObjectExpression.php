<?php

namespace pg\classes\executor\expression;

interface ObjectExpression extends Expression{

}
