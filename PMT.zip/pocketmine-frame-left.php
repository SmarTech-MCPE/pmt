<?php
include("lang/setlang.php");
define('PACKAGE', 'pocketmine-frame-left');

// gettext setting
bindtextdomain(PACKAGE, 'lang'); // or $your_path/lang, ex: /var/www/test/lang
textdomain(PACKAGE);
?>
<html>
<head>
<link rel="stylesheet" href="/css/main.css" />
</head>
<body>

	<ul class="menu">
		<li><a href="/phar.php" target="content"><?php echo _('Conversion Zip » Phar'); ?></a></li><br>
		<li><a href="/unphar.php" target="content"><?php echo _('Conversion Phar » Zip'); ?></a></li><br>
		<li><a href="/insta/" target="_blank"><?php echo _('Générateur + Convertisseur de plugin gist'); ?></a></li><br>
		<!--		<li><a href="/data/builds/" target="content">Archives des dernières conversions</a></li>-->
		<li><a href="/varDump.php" target="content"><?php echo _('<code>var_dump()</code> viewer (les styles <code>xdebug</code> ne sont pas encore supportés)'); ?></a></li><br>
		<li><a href="/crashdump/" target="content"><?php echo _('Analyse de crash dumps PocketMine'); ?></a></li><br>
		<li><a href="/pmb/" target="content"><?php echo _('Archives des builds PocketMine'); ?></a></li><br>
		<li><a href="/api2/" target="content"><?php echo _('Injecteur d'API 3.0.0'); ?></a></li><br>
		<li><a href="#" class="disabled"><?php echo _('<strong>[A VENIR]</strong> Générateur de plugin'); ?></a></li><br>
	</ul>
	<input type="button" value="<?php echo _('Recharger le cadre de liens'); ?>" onclick="parent.content.location.reload()">
	<br>

</body>
</html>
