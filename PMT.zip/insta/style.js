$(document).ready(function(){
    $(".title").after("<hr style='padding-top: 0;'>");
});
