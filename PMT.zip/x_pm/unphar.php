<?php
include_once __DIR__ . "/functions.php";
forceTerms();
?>
<html>
<head>
	<title>Phar-to-Zip Converter</title>
	<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<h1 class="title">Phar-to-Zip Converter</h1>
</body>
</html>
