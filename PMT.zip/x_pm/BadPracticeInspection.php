<?php

/** @noinspection PhpIllegalPsrClassPathInspection */
namespace pm;

class BadPracticeInspection implements Inspection{
	public function inspect($path, &$warnings){
		// TODO: Implement inspect() method.
	}
}
