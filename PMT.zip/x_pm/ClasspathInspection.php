<?php

/** @noinspection PhpIllegalPsrClassPathInspection */
namespace pm;

class ClasspathInspection implements Inspection{
	public function inspect($path, &$warnings){
		// TODO: Implement inspect() method.
	}
}
