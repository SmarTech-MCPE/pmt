<?php
include("lang/setlang.php");
define('PACKAGE', 'phar');

// gettext setting
bindtextdomain(PACKAGE, 'lang'); // or $your_path/lang, ex: /var/www/test/lang
textdomain(PACKAGE);
?>
<html>
<head>
	<title>Zip » Phar</title>
	<link rel="stylesheet" href="/css/main.css" />
	<script>
	function fillPmStub(){
		document.getElementById("stubInput").value = '<?= "<?php" ?> define("pocketmine\\\\PATH", "phar://". __FILE__ ."/"); require_once("phar://". __FILE__ ."/src/pocketmine/PocketMine.php");  __HALT_COMPILER();';
	}
	</script>
</head>
<body>
	<h1><?php echo _('Conversion <b>zip » phar»</b>'); ?></h1>
	<h3><?php echo _('Comment l'utiliser ?'); ?></h3>
	<ol>
		<li><?php echo _('Ecrivez votre plugin,'); ?></li>
		<li><?php echo _('Utilisez vos fichiers dans la bonne structure (avec les namespaces, etc...),'); ?></li>
		<li><?php echo _('Créez un fichier ZIP et mettez votre structure dans celui-ci. Vous pouvez la placer n'importe où dans le fichier ZIP, mais seul le dossier avec le plugin.yml (et les sous-dossiers) sera inclus.'); ?></li>
		<li><?php echo _('Uploadez le fichier ci-dessous :)'); ?></li>
	</ol>
	<form method="post" action="/phar-result.php" enctype="multipart/form-data">
		<p><input type="file" name="file"></p>
		<p><?php echo _('Stub (ne vous en occupez pas si vous ne savez pas de quoi il s'agit) :'); ?>
			<?php
			echo '<input type="text" name="stub" value="';
			echo '<?php __HALT_COMPILER();';
			echo '" size="100" id="stubInput">';
			?>
			<button onclick="fillPmStub(); return false;"><?php echo _('Utiliser le stub de PocketMine-MP.phar'); ?></button>
		</p>
		<p><?php echo _('Modifier le plugin avec :'); ?> <br>
			<input type="checkbox" name="tune_top_namespace_optimization">
				<?php echo _('Optimiser les références en ajoutant un préfix <code>\</code> pour indiquer si il s'agit d'une bonne référence de namespaces.'); ?><br>
			<input type="checkbox" name="tune_obfuscation"> <?php echo _('Obfuscate code'); ?>
		</p>
		<p><font color="#8b0000"><?php echo _('Attention : Utiliser une de ces options rique de supprimer tout les commentaires du code.'); ?></font></p>
		<p>
			<?php echo _('Effectuer les opérations suivantes (optionnel) :'); ?> <br>
			<input type="checkbox" name="inspection_classpath"> <?php echo _('Vérifier les classes (classpath)'); ?><br>
			<input type="checkbox" name="inspection_bad_practice"> <?php echo _('Analyser une mauvaise pratique'); ?><br>
			<input type="checkbox" name="inspection_lint"> <?php echo _('Analyser les erreurs syntaxiques'); ?>
		</p>
		<p><input type="submit" value="<?php echo _('Créer le phar'); ?>"></p>
	</form>
<pre>
	<?php echo _("Informations :
	Ce service est fourni gratuitement et n'est pas garanti pour être toujours disponible.
Cette page (unphar.php) convertit uniquement les fichiers téléchargés depuis les utilisateurs d'un format phar vers un format zip et, dans le processus, le fichier phar est extrait dans les fichiers sur le système de fichiers du serveur (ce qui n'est pas prévu sur le site) . Cette page décompose les fichiers téléchargés AS-IS et le processus est entièrement automatisé.
Ce site web n'est en aucun cas affilié à PocketMine-MP (http://pocketmine.net), un projet open source développé par PocketMine Team, ou Minecraft: PE, un jeu Logiciel développé par Mojang.
Nous (le propriétaire de ce site Web) ne sommes pas responsables des actes liés aux violations du droit d'auteur et à d'autres actes illégaux. Tous les contenus dans les fichiers téléchargés sont générés à l'aide du fichier téléchargé ou du logiciel utilisé pour ce site. ");?>"); ?>
</pre>
</body>
</html>
